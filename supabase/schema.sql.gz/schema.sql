-- Diet Copilot V0.5 — Supabase schema
-- Current for September 2026. Safe for fresh installs and upgrades from V0.2/V0.3/V0.4.
-- Safe to run on a fresh project OR on top of the V0.2 schema.
-- Uses explicit Data API grants and owner-only RLS.
-- Browser clients must use only the publishable/anon client key.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  calorie_target integer not null default 2300 check (calorie_target > 0),
  protein_target numeric(7,2) not null default 160 check (protein_target >= 0),
  goal_weight numeric(7,2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.daily_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  log_date date not null,
  calorie_target integer not null check (calorie_target > 0),
  protein_target numeric(7,2) not null check (protein_target >= 0),
  status text not null default 'open' check (status in ('open','complete','partial')),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, log_date)
);

create table if not exists public.meals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  daily_log_id uuid not null references public.daily_logs(id) on delete cascade,
  meal_type text not null check (char_length(meal_type) between 1 and 40),
  title text not null check (char_length(title) between 1 and 120),
  calories integer not null default 0 check (calories >= 0),
  protein numeric(8,2) not null default 0 check (protein >= 0),
  confidence text not null default 'medium' check (confidence in ('high','medium','low')),
  source text not null default 'text_estimate' check (source in ('manual_exact','nutrition_label','weighed','saved_food','text_estimate','photo_estimate','restaurant_estimate','ai_adjusted')),
  original_input text,
  notes text,
  eaten_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.saved_foods (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  quantity_text text,
  calories integer not null default 0 check (calories >= 0),
  protein numeric(8,2) not null default 0 check (protein >= 0),
  confidence text not null default 'high' check (confidence in ('high','medium','low')),
  source text not null default 'manual_exact' check (source in ('manual_exact','nutrition_label','weighed','text_estimate','photo_estimate','restaurant_estimate','ai_adjusted')),
  favorite boolean not null default false,
  use_count integer not null default 0 check (use_count >= 0),
  last_used_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.meal_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  meal_id uuid not null references public.meals(id) on delete cascade,
  saved_food_id uuid references public.saved_foods(id) on delete set null,
  name text not null check (char_length(name) between 1 and 120),
  quantity_text text,
  calories integer not null default 0 check (calories >= 0),
  protein numeric(8,2) not null default 0 check (protein >= 0),
  confidence text not null default 'medium' check (confidence in ('high','medium','low')),
  source text not null default 'text_estimate' check (source in ('manual_exact','nutrition_label','weighed','saved_food','text_estimate','photo_estimate','restaurant_estimate','ai_adjusted')),
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.saved_meals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  meal_type text not null default 'Other' check (char_length(meal_type) between 1 and 40),
  favorite boolean not null default false,
  use_count integer not null default 0 check (use_count >= 0),
  last_used_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.saved_meal_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  saved_meal_id uuid not null references public.saved_meals(id) on delete cascade,
  saved_food_id uuid references public.saved_foods(id) on delete set null,
  name text not null check (char_length(name) between 1 and 120),
  quantity_text text,
  calories integer not null default 0 check (calories >= 0),
  protein numeric(8,2) not null default 0 check (protein >= 0),
  confidence text not null default 'high' check (confidence in ('high','medium','low')),
  source text not null default 'saved_food' check (source in ('manual_exact','nutrition_label','weighed','saved_food','text_estimate','photo_estimate','restaurant_estimate','ai_adjusted')),
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.weight_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  entry_date date not null,
  weight numeric(7,2) not null check (weight > 0),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, entry_date)
);

create table if not exists public.change_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  entity text not null,
  entity_id text not null,
  action text not null,
  before_data jsonb,
  after_data jsonb,
  created_at timestamptz not null default now()
);

alter table public.weight_entries add column if not exists updated_at timestamptz not null default now();

create index if not exists daily_logs_user_date_idx on public.daily_logs(user_id, log_date desc);
create index if not exists meals_user_created_idx on public.meals(user_id, created_at desc);
create index if not exists meals_daily_log_idx on public.meals(daily_log_id);
create index if not exists meal_items_meal_order_idx on public.meal_items(meal_id, sort_order);
create index if not exists meal_items_user_idx on public.meal_items(user_id);
create index if not exists saved_foods_user_favorite_idx on public.saved_foods(user_id, favorite desc, use_count desc);
create index if not exists saved_meals_user_favorite_idx on public.saved_meals(user_id, favorite desc, use_count desc);
create index if not exists saved_meal_items_parent_idx on public.saved_meal_items(saved_meal_id, sort_order);
create index if not exists weight_entries_user_date_idx on public.weight_entries(user_id, entry_date desc);
create index if not exists change_log_user_created_idx on public.change_log(user_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.daily_logs enable row level security;
alter table public.meals enable row level security;
alter table public.meal_items enable row level security;
alter table public.saved_foods enable row level security;
alter table public.saved_meals enable row level security;
alter table public.saved_meal_items enable row level security;
alter table public.weight_entries enable row level security;
alter table public.change_log enable row level security;

-- Drop/recreate named policies so the script can be rerun while iterating.
drop policy if exists "profiles own rows" on public.profiles;
drop policy if exists "daily_logs own rows" on public.daily_logs;
drop policy if exists "meals own rows" on public.meals;
drop policy if exists "meal_items own rows" on public.meal_items;
drop policy if exists "saved_foods own rows" on public.saved_foods;
drop policy if exists "saved_meals own rows" on public.saved_meals;
drop policy if exists "saved_meal_items own rows" on public.saved_meal_items;
drop policy if exists "weight_entries own rows" on public.weight_entries;
drop policy if exists "change_log own rows" on public.change_log;

create policy "profiles own rows" on public.profiles for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "daily_logs own rows" on public.daily_logs for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "meals own rows" on public.meals for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "meal_items own rows" on public.meal_items for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "saved_foods own rows" on public.saved_foods for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "saved_meals own rows" on public.saved_meals for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "saved_meal_items own rows" on public.saved_meal_items for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "weight_entries own rows" on public.weight_entries for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "change_log own rows" on public.change_log for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

-- Grants and RLS are separate layers on current Supabase projects.
revoke all on table public.profiles, public.daily_logs, public.meals, public.meal_items, public.saved_foods, public.saved_meals, public.saved_meal_items, public.weight_entries, public.change_log from anon;
grant select, insert, update, delete on table public.profiles, public.daily_logs, public.meals, public.meal_items, public.saved_foods, public.saved_meals, public.saved_meal_items, public.weight_entries, public.change_log to authenticated;

-- Read-friendly daily summary. security_invoker makes underlying RLS apply.
create or replace view public.daily_summary
with (security_invoker = true)
as
select
  d.user_id,
  d.log_date,
  d.status,
  d.calorie_target,
  d.protein_target,
  coalesce(sum(m.calories),0)::bigint as calories_consumed,
  coalesce(sum(m.protein),0)::numeric(10,2) as protein_consumed,
  count(m.id)::integer as meal_count,
  d.calorie_target - coalesce(sum(m.calories),0)::integer as calories_remaining
from public.daily_logs d
left join public.meals m on m.daily_log_id = d.id
where d.user_id = (select auth.uid())
group by d.user_id, d.log_date, d.status, d.calorie_target, d.protein_target;

-- Item-rich view for ChatGPT/analytics reads.
create or replace view public.meal_details
with (security_invoker = true)
as
select
  m.id,
  m.user_id,
  d.log_date,
  m.meal_type,
  m.title,
  m.calories,
  m.protein,
  m.confidence,
  m.source,
  m.original_input,
  m.notes,
  m.created_at,
  coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', mi.id,
        'name', mi.name,
        'quantity', mi.quantity_text,
        'calories', mi.calories,
        'protein', mi.protein,
        'confidence', mi.confidence,
        'source', mi.source,
        'saved_food_id', mi.saved_food_id
      ) order by mi.sort_order
    ) filter (where mi.id is not null),
    '[]'::jsonb
  ) as items
from public.meals m
join public.daily_logs d on d.id = m.daily_log_id
left join public.meal_items mi on mi.meal_id = m.id
where m.user_id = (select auth.uid())
group by m.id, d.log_date;

revoke all on public.daily_summary, public.meal_details from anon;
grant select on public.daily_summary, public.meal_details to authenticated;

-- AI-action RPC: one authenticated call can create a structured meal and its items.
-- It is SECURITY INVOKER, so normal grants + RLS remain in force.
create or replace function public.log_meal_from_ai(
  p_log_date date,
  p_meal_type text,
  p_title text,
  p_items jsonb,
  p_confidence text default 'medium',
  p_source text default 'text_estimate',
  p_original_input text default null,
  p_notes text default null
) returns uuid
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_day_id uuid;
  v_meal_id uuid := gen_random_uuid();
  v_calorie_target integer := 2300;
  v_protein_target numeric := 160;
  v_total_calories integer := 0;
  v_total_protein numeric := 0;
  v_item jsonb;
  v_pos bigint;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then raise exception 'p_items must be a non-empty JSON array'; end if;

  select calorie_target, protein_target into v_calorie_target, v_protein_target
  from public.profiles where user_id = v_uid;
  v_calorie_target := coalesce(v_calorie_target, 2300);
  v_protein_target := coalesce(v_protein_target, 160);

  insert into public.daily_logs(user_id, log_date, calorie_target, protein_target, status)
  values (v_uid, p_log_date, v_calorie_target, v_protein_target, case when p_log_date = current_date then 'open' else 'partial' end)
  on conflict (user_id, log_date) do update set updated_at = now()
  returning id into v_day_id;

  select
    coalesce(sum(coalesce((x.value->>'calories')::numeric,0)),0)::integer,
    coalesce(sum(coalesce((x.value->>'protein')::numeric,0)),0)
  into v_total_calories, v_total_protein
  from jsonb_array_elements(p_items) as x(value);

  insert into public.meals(id, user_id, daily_log_id, meal_type, title, calories, protein, confidence, source, original_input, notes, eaten_at)
  values (v_meal_id, v_uid, v_day_id, p_meal_type, p_title, v_total_calories, v_total_protein, p_confidence, p_source, p_original_input, p_notes, p_log_date::timestamp + time '12:00') ;

  for v_item, v_pos in
    select value, ordinality from jsonb_array_elements(p_items) with ordinality as t(value, ordinality)
  loop
    insert into public.meal_items(user_id, meal_id, name, quantity_text, calories, protein, confidence, source, sort_order)
    values (
      v_uid,
      v_meal_id,
      coalesce(nullif(v_item->>'name',''), 'Food'),
      nullif(v_item->>'quantity',''),
      coalesce((v_item->>'calories')::integer,0),
      coalesce((v_item->>'protein')::numeric,0),
      coalesce(nullif(v_item->>'confidence',''), p_confidence),
      coalesce(nullif(v_item->>'source',''), p_source),
      (v_pos - 1)::integer
    );
  end loop;

  return v_meal_id;
end;
$$;

create or replace function public.log_weight_from_ai(
  p_entry_date date,
  p_weight numeric,
  p_notes text default null
) returns uuid
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_id uuid;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  insert into public.weight_entries(user_id, entry_date, weight, notes)
  values (v_uid, p_entry_date, p_weight, p_notes)
  on conflict (user_id, entry_date)
  do update set weight = excluded.weight, notes = excluded.notes
  returning id into v_id;
  return v_id;
end;
$$;

revoke all on function public.log_meal_from_ai(date,text,text,jsonb,text,text,text,text) from public, anon;
revoke all on function public.log_weight_from_ai(date,numeric,text) from public, anon;
grant execute on function public.log_meal_from_ai(date,text,text,jsonb,text,text,text,text) to authenticated;
grant execute on function public.log_weight_from_ai(date,numeric,text) to authenticated;

-- Optional realtime refresh for multi-device sessions. This block is idempotent.
do $$
declare
  t text;
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['profiles','daily_logs','meals','meal_items','weight_entries','saved_foods','saved_meals','saved_meal_items']
    loop
      if not exists (
        select 1 from pg_publication_tables
        where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t
      ) then
        execute format('alter publication supabase_realtime add table public.%I', t);
      end if;
    end loop;
  end if;
end $$;

-- ============================================================
-- V0.4 — AI mutation safety, uncertainty ranges, conflict guards
-- ============================================================

-- Optional uncertainty ranges for estimated meals/items.
alter table public.meals add column if not exists calories_low integer;
alter table public.meals add column if not exists calories_high integer;
alter table public.meal_items add column if not exists calories_low integer;
alter table public.meal_items add column if not exists calories_high integer;
alter table public.saved_meal_items add column if not exists calories_low integer;
alter table public.saved_meal_items add column if not exists calories_high integer;

-- Keep estimate ranges internally consistent.
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'meals_calorie_range_check' and conrelid = 'public.meals'::regclass) then
    alter table public.meals add constraint meals_calorie_range_check check (
      (calories_low is null or calories_low >= 0) and
      (calories_high is null or calories_high >= 0) and
      (calories_low is null or calories_high is null or calories_low <= calories_high) and
      (calories_low is null or calories >= calories_low) and
      (calories_high is null or calories <= calories_high)
    );
  end if;
  if not exists (select 1 from pg_constraint where conname = 'meal_items_calorie_range_check' and conrelid = 'public.meal_items'::regclass) then
    alter table public.meal_items add constraint meal_items_calorie_range_check check (
      (calories_low is null or calories_low >= 0) and
      (calories_high is null or calories_high >= 0) and
      (calories_low is null or calories_high is null or calories_low <= calories_high) and
      (calories_low is null or calories >= calories_low) and
      (calories_high is null or calories <= calories_high)
    );
  end if;
  if not exists (select 1 from pg_constraint where conname = 'saved_meal_items_calorie_range_check' and conrelid = 'public.saved_meal_items'::regclass) then
    alter table public.saved_meal_items add constraint saved_meal_items_calorie_range_check check (
      (calories_low is null or calories_low >= 0) and
      (calories_high is null or calories_high >= 0) and
      (calories_low is null or calories_high is null or calories_low <= calories_high) and
      (calories_low is null or calories >= calories_low) and
      (calories_high is null or calories <= calories_high)
    );
  end if;
end $$;


-- Extend the structured read view without changing the original column order.
create or replace view public.meal_details
with (security_invoker = true)
as
select
  m.id,
  m.user_id,
  d.log_date,
  m.meal_type,
  m.title,
  m.calories,
  m.protein,
  m.confidence,
  m.source,
  m.original_input,
  m.notes,
  m.created_at,
  coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', mi.id,
        'name', mi.name,
        'quantity', mi.quantity_text,
        'calories', mi.calories,
        'protein', mi.protein,
        'calories_low', mi.calories_low,
        'calories_high', mi.calories_high,
        'confidence', mi.confidence,
        'source', mi.source,
        'saved_food_id', mi.saved_food_id
      ) order by mi.sort_order
    ) filter (where mi.id is not null),
    '[]'::jsonb
  ) as items,
  m.updated_at,
  m.calories_low,
  m.calories_high
from public.meals m
join public.daily_logs d on d.id = m.daily_log_id
left join public.meal_items mi on mi.meal_id = m.id
where m.user_id = (select auth.uid())
group by m.id, d.log_date;

-- Server-side AI action ledger. This is the authoritative undo/audit trail for
-- mutations made through the AI RPC surface.
create table if not exists public.ai_actions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  request_id text not null,
  action_type text not null check (action_type in ('create_meal','update_meal','delete_meal','log_weight','update_weight')),
  entity_type text not null check (entity_type in ('meal','weight')),
  entity_id uuid,
  before_data jsonb,
  after_data jsonb,
  undone_at timestamptz,
  created_at timestamptz not null default now(),
  unique(user_id, request_id)
);

create index if not exists ai_actions_user_created_idx on public.ai_actions(user_id, created_at desc);
alter table public.ai_actions enable row level security;
drop policy if exists "ai_actions own rows" on public.ai_actions;
create policy "ai_actions own rows" on public.ai_actions
for all to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);
revoke all on table public.ai_actions from anon;
grant select, insert, update, delete on table public.ai_actions to authenticated;

-- Maintain updated_at server-side as well as client-side. This makes optimistic
-- conflict checks meaningful even for connector/RPC writes.
create or replace function public.diet_copilot_touch_updated_at()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

revoke all on function public.diet_copilot_touch_updated_at() from public, anon;
grant execute on function public.diet_copilot_touch_updated_at() to authenticated;

do $$
declare t text;
begin
  foreach t in array array['profiles','daily_logs','meals','meal_items','saved_foods','saved_meals','saved_meal_items','weight_entries'] loop
    execute format('drop trigger if exists diet_copilot_touch_updated_at on public.%I', t);
    execute format('create trigger diet_copilot_touch_updated_at before update on public.%I for each row execute function public.diet_copilot_touch_updated_at()', t);
  end loop;
end $$;

-- The V0.3 create-only AI functions are replaced by idempotent versions.
drop function if exists public.log_meal_from_ai(date,text,text,jsonb,text,text,text,text);
drop function if exists public.log_weight_from_ai(date,numeric,text);

create or replace function public.log_meal_from_ai(
  p_log_date date,
  p_meal_type text,
  p_title text,
  p_items jsonb,
  p_confidence text default 'medium',
  p_source text default 'text_estimate',
  p_original_input text default null,
  p_notes text default null,
  p_request_id text default null
) returns uuid
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_day_id uuid;
  v_meal_id uuid := gen_random_uuid();
  v_existing_entity uuid;
  v_request_id text := coalesce(nullif(trim(p_request_id),''), gen_random_uuid()::text);
  v_calorie_target integer := 2300;
  v_protein_target numeric := 160;
  v_total_calories integer := 0;
  v_total_protein numeric := 0;
  v_total_low integer := 0;
  v_total_high integer := 0;
  v_has_range boolean := false;
  v_item jsonb;
  v_pos bigint;
  v_after jsonb;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then raise exception 'p_items must be a non-empty JSON array'; end if;
  if p_confidence not in ('high','medium','low') then raise exception 'Invalid confidence'; end if;
  if p_source not in ('manual_exact','nutrition_label','weighed','saved_food','text_estimate','photo_estimate','restaurant_estimate','ai_adjusted') then raise exception 'Invalid source'; end if;

  select entity_id into v_existing_entity
  from public.ai_actions
  where user_id = v_uid and request_id = v_request_id and action_type = 'create_meal'
  limit 1;
  if v_existing_entity is not null then return v_existing_entity; end if;

  select calorie_target, protein_target into v_calorie_target, v_protein_target
  from public.profiles where user_id = v_uid;
  v_calorie_target := coalesce(v_calorie_target, 2300);
  v_protein_target := coalesce(v_protein_target, 160);

  insert into public.daily_logs(user_id, log_date, calorie_target, protein_target, status)
  values (v_uid, p_log_date, v_calorie_target, v_protein_target, case when p_log_date = current_date then 'open' else 'partial' end)
  on conflict (user_id, log_date) do update set updated_at = now()
  returning id into v_day_id;

  select
    coalesce(sum(coalesce((x.value->>'calories')::numeric,0)),0)::integer,
    coalesce(sum(coalesce((x.value->>'protein')::numeric,0)),0),
    coalesce(sum(coalesce((x.value->>'calories_low')::numeric, (x.value->>'calories')::numeric, 0)),0)::integer,
    coalesce(sum(coalesce((x.value->>'calories_high')::numeric, (x.value->>'calories')::numeric, 0)),0)::integer,
    bool_or(x.value ? 'calories_low' or x.value ? 'calories_high')
  into v_total_calories, v_total_protein, v_total_low, v_total_high, v_has_range
  from jsonb_array_elements(p_items) as x(value);

  insert into public.meals(id, user_id, daily_log_id, meal_type, title, calories, protein, calories_low, calories_high, confidence, source, original_input, notes, eaten_at)
  values (v_meal_id, v_uid, v_day_id, p_meal_type, p_title, v_total_calories, v_total_protein,
    case when v_has_range then v_total_low else null end,
    case when v_has_range then v_total_high else null end,
    p_confidence, p_source, p_original_input, p_notes, p_log_date::timestamp + time '12:00');

  for v_item, v_pos in
    select value, ordinality from jsonb_array_elements(p_items) with ordinality as t(value, ordinality)
  loop
    insert into public.meal_items(user_id, meal_id, name, quantity_text, calories, protein, calories_low, calories_high, confidence, source, sort_order)
    values (
      v_uid,
      v_meal_id,
      coalesce(nullif(v_item->>'name',''), 'Food'),
      nullif(v_item->>'quantity',''),
      greatest(coalesce((v_item->>'calories')::integer,0),0),
      greatest(coalesce((v_item->>'protein')::numeric,0),0),
      case when v_item ? 'calories_low' then greatest((v_item->>'calories_low')::integer,0) else null end,
      case when v_item ? 'calories_high' then greatest((v_item->>'calories_high')::integer,0) else null end,
      coalesce(nullif(v_item->>'confidence',''), p_confidence),
      coalesce(nullif(v_item->>'source',''), p_source),
      (v_pos - 1)::integer
    );
  end loop;

  select jsonb_build_object(
    'meal', to_jsonb(m),
    'items', coalesce((select jsonb_agg(to_jsonb(mi) order by mi.sort_order) from public.meal_items mi where mi.meal_id = m.id), '[]'::jsonb)
  ) into v_after from public.meals m where m.id = v_meal_id and m.user_id = v_uid;

  insert into public.ai_actions(user_id, request_id, action_type, entity_type, entity_id, before_data, after_data)
  values (v_uid, v_request_id, 'create_meal', 'meal', v_meal_id, null, v_after);

  return v_meal_id;
end;
$$;

create or replace function public.update_meal_from_ai(
  p_meal_id uuid,
  p_patch jsonb default '{}'::jsonb,
  p_items jsonb default null,
  p_expected_updated_at timestamptz default null,
  p_request_id text default null
) returns uuid
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_request_id text := coalesce(nullif(trim(p_request_id),''), gen_random_uuid()::text);
  v_existing_entity uuid;
  v_meal public.meals%rowtype;
  v_before jsonb;
  v_after jsonb;
  v_item jsonb;
  v_pos bigint;
  v_total_calories integer;
  v_total_protein numeric;
  v_total_low integer;
  v_total_high integer;
  v_has_range boolean;
  v_day_id uuid;
  v_calorie_target integer := 2300;
  v_protein_target numeric := 160;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  select entity_id into v_existing_entity from public.ai_actions where user_id = v_uid and request_id = v_request_id limit 1;
  if v_existing_entity is not null then return v_existing_entity; end if;

  select * into v_meal from public.meals where id = p_meal_id and user_id = v_uid for update;
  if not found then raise exception 'Meal not found'; end if;
  if p_expected_updated_at is not null and abs(extract(epoch from (v_meal.updated_at - p_expected_updated_at))) > 0.001 then
    raise exception 'Conflict: meal changed since it was read';
  end if;

  select jsonb_build_object(
    'meal', to_jsonb(v_meal),
    'items', coalesce((select jsonb_agg(to_jsonb(mi) order by mi.sort_order) from public.meal_items mi where mi.meal_id = p_meal_id), '[]'::jsonb)
  ) into v_before;

  if p_patch ? 'log_date' then
    select calorie_target, protein_target into v_calorie_target, v_protein_target from public.profiles where user_id = v_uid;
    v_calorie_target := coalesce(v_calorie_target, 2300);
    v_protein_target := coalesce(v_protein_target, 160);
    insert into public.daily_logs(user_id, log_date, calorie_target, protein_target, status)
    values (v_uid, (p_patch->>'log_date')::date, v_calorie_target, v_protein_target, case when (p_patch->>'log_date')::date = current_date then 'open' else 'partial' end)
    on conflict (user_id, log_date) do update set updated_at = now()
    returning id into v_day_id;
  end if;

  update public.meals set
    daily_log_id = coalesce(v_day_id, daily_log_id),
    meal_type = coalesce(nullif(p_patch->>'meal_type',''), meal_type),
    title = coalesce(nullif(p_patch->>'title',''), title),
    confidence = coalesce(nullif(p_patch->>'confidence',''), confidence),
    source = coalesce(nullif(p_patch->>'source',''), source),
    original_input = case when p_patch ? 'original_input' then p_patch->>'original_input' else original_input end,
    notes = case when p_patch ? 'notes' then p_patch->>'notes' else notes end,
    eaten_at = case when p_patch ? 'log_date' then (p_patch->>'log_date')::date::timestamp + time '12:00' else eaten_at end
  where id = p_meal_id and user_id = v_uid;

  if p_items is not null then
    if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then raise exception 'p_items must be null or a non-empty JSON array'; end if;
    delete from public.meal_items where meal_id = p_meal_id and user_id = v_uid;
    for v_item, v_pos in select value, ordinality from jsonb_array_elements(p_items) with ordinality as t(value, ordinality)
    loop
      insert into public.meal_items(user_id, meal_id, name, quantity_text, calories, protein, calories_low, calories_high, confidence, source, sort_order)
      values (
        v_uid, p_meal_id, coalesce(nullif(v_item->>'name',''),'Food'), nullif(v_item->>'quantity',''),
        greatest(coalesce((v_item->>'calories')::integer,0),0), greatest(coalesce((v_item->>'protein')::numeric,0),0),
        case when v_item ? 'calories_low' then greatest((v_item->>'calories_low')::integer,0) else null end,
        case when v_item ? 'calories_high' then greatest((v_item->>'calories_high')::integer,0) else null end,
        coalesce(nullif(v_item->>'confidence',''), (select confidence from public.meals where id=p_meal_id)),
        coalesce(nullif(v_item->>'source',''), (select source from public.meals where id=p_meal_id)),
        (v_pos - 1)::integer
      );
    end loop;

    select
      coalesce(sum(calories),0)::integer,
      coalesce(sum(protein),0),
      coalesce(sum(coalesce(calories_low, calories)),0)::integer,
      coalesce(sum(coalesce(calories_high, calories)),0)::integer,
      bool_or(calories_low is not null or calories_high is not null)
    into v_total_calories, v_total_protein, v_total_low, v_total_high, v_has_range
    from public.meal_items where meal_id = p_meal_id and user_id = v_uid;

    update public.meals set calories = v_total_calories, protein = v_total_protein,
      calories_low = case when v_has_range then v_total_low else null end,
      calories_high = case when v_has_range then v_total_high else null end
    where id = p_meal_id and user_id = v_uid;
  end if;

  select jsonb_build_object(
    'meal', to_jsonb(m),
    'items', coalesce((select jsonb_agg(to_jsonb(mi) order by mi.sort_order) from public.meal_items mi where mi.meal_id = m.id), '[]'::jsonb)
  ) into v_after from public.meals m where m.id = p_meal_id and m.user_id = v_uid;

  insert into public.ai_actions(user_id, request_id, action_type, entity_type, entity_id, before_data, after_data)
  values (v_uid, v_request_id, 'update_meal', 'meal', p_meal_id, v_before, v_after);
  return p_meal_id;
end;
$$;

create or replace function public.delete_meal_from_ai(
  p_meal_id uuid,
  p_expected_updated_at timestamptz default null,
  p_request_id text default null
) returns uuid
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_request_id text := coalesce(nullif(trim(p_request_id),''), gen_random_uuid()::text);
  v_existing_entity uuid;
  v_meal public.meals%rowtype;
  v_before jsonb;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  select entity_id into v_existing_entity from public.ai_actions where user_id = v_uid and request_id = v_request_id limit 1;
  if v_existing_entity is not null then return v_existing_entity; end if;
  select * into v_meal from public.meals where id = p_meal_id and user_id = v_uid for update;
  if not found then raise exception 'Meal not found'; end if;
  if p_expected_updated_at is not null and abs(extract(epoch from (v_meal.updated_at - p_expected_updated_at))) > 0.001 then raise exception 'Conflict: meal changed since it was read'; end if;

  select jsonb_build_object(
    'meal', to_jsonb(v_meal),
    'items', coalesce((select jsonb_agg(to_jsonb(mi) order by mi.sort_order) from public.meal_items mi where mi.meal_id = p_meal_id), '[]'::jsonb)
  ) into v_before;

  delete from public.meals where id = p_meal_id and user_id = v_uid;
  insert into public.ai_actions(user_id, request_id, action_type, entity_type, entity_id, before_data, after_data)
  values (v_uid, v_request_id, 'delete_meal', 'meal', p_meal_id, v_before, null);
  return p_meal_id;
end;
$$;

create or replace function public.log_weight_from_ai(
  p_entry_date date,
  p_weight numeric,
  p_notes text default null,
  p_request_id text default null
) returns uuid
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_request_id text := coalesce(nullif(trim(p_request_id),''), gen_random_uuid()::text);
  v_existing_entity uuid;
  v_id uuid;
  v_before jsonb;
  v_after jsonb;
  v_action text;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  select entity_id into v_existing_entity from public.ai_actions where user_id = v_uid and request_id = v_request_id limit 1;
  if v_existing_entity is not null then return v_existing_entity; end if;
  select to_jsonb(w) into v_before from public.weight_entries w where w.user_id = v_uid and w.entry_date = p_entry_date;
  v_action := case when v_before is null then 'log_weight' else 'update_weight' end;
  insert into public.weight_entries(user_id, entry_date, weight, notes)
  values (v_uid, p_entry_date, p_weight, p_notes)
  on conflict (user_id, entry_date) do update set weight = excluded.weight, notes = excluded.notes
  returning id into v_id;
  select to_jsonb(w) into v_after from public.weight_entries w where w.id = v_id and w.user_id = v_uid;
  insert into public.ai_actions(user_id, request_id, action_type, entity_type, entity_id, before_data, after_data)
  values (v_uid, v_request_id, v_action, 'weight', v_id, v_before, v_after);
  return v_id;
end;
$$;

create or replace function public.undo_ai_action(p_action_id uuid)
returns boolean
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  a public.ai_actions%rowtype;
  j jsonb;
  item jsonb;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  select * into a from public.ai_actions where id = p_action_id and user_id = v_uid for update;
  if not found then raise exception 'AI action not found'; end if;
  if a.undone_at is not null then return true; end if;

  if a.entity_type = 'meal' then
    if a.action_type = 'create_meal' then
      delete from public.meals where id = a.entity_id and user_id = v_uid;
    elsif a.action_type in ('update_meal','delete_meal') then
      j := a.before_data->'meal';
      if j is null then raise exception 'Missing meal snapshot'; end if;
      insert into public.meals(id,user_id,daily_log_id,meal_type,title,calories,protein,calories_low,calories_high,confidence,source,original_input,notes,eaten_at,created_at,updated_at)
      values (
        (j->>'id')::uuid, v_uid, (j->>'daily_log_id')::uuid, j->>'meal_type', j->>'title',
        coalesce((j->>'calories')::integer,0), coalesce((j->>'protein')::numeric,0),
        nullif(j->>'calories_low','')::integer, nullif(j->>'calories_high','')::integer,
        j->>'confidence', j->>'source', j->>'original_input', j->>'notes',
        nullif(j->>'eaten_at','')::timestamptz, coalesce(nullif(j->>'created_at','')::timestamptz, now()), now()
      )
      on conflict (id) do update set
        daily_log_id=excluded.daily_log_id, meal_type=excluded.meal_type, title=excluded.title,
        calories=excluded.calories, protein=excluded.protein, calories_low=excluded.calories_low, calories_high=excluded.calories_high,
        confidence=excluded.confidence, source=excluded.source, original_input=excluded.original_input, notes=excluded.notes, eaten_at=excluded.eaten_at;
      delete from public.meal_items where meal_id = a.entity_id and user_id = v_uid;
      for item in select value from jsonb_array_elements(coalesce(a.before_data->'items','[]'::jsonb)) t(value)
      loop
        insert into public.meal_items(id,user_id,meal_id,saved_food_id,name,quantity_text,calories,protein,calories_low,calories_high,confidence,source,sort_order,created_at,updated_at)
        values (
          coalesce(nullif(item->>'id','')::uuid, gen_random_uuid()), v_uid, a.entity_id, nullif(item->>'saved_food_id','')::uuid,
          item->>'name', item->>'quantity_text', coalesce((item->>'calories')::integer,0), coalesce((item->>'protein')::numeric,0),
          nullif(item->>'calories_low','')::integer, nullif(item->>'calories_high','')::integer,
          item->>'confidence', item->>'source', coalesce((item->>'sort_order')::integer,0),
          coalesce(nullif(item->>'created_at','')::timestamptz,now()), now()
        );
      end loop;
    end if;
  elsif a.entity_type = 'weight' then
    if a.before_data is null then
      delete from public.weight_entries where id = a.entity_id and user_id = v_uid;
    else
      j := a.before_data;
      insert into public.weight_entries(id,user_id,entry_date,weight,notes,created_at)
      values ((j->>'id')::uuid,v_uid,(j->>'entry_date')::date,(j->>'weight')::numeric,j->>'notes',coalesce(nullif(j->>'created_at','')::timestamptz,now()))
      on conflict (user_id, entry_date) do update set weight=excluded.weight, notes=excluded.notes;
    end if;
  end if;

  update public.ai_actions set undone_at = now() where id = p_action_id and user_id = v_uid;
  return true;
end;
$$;

-- Compact context payload designed for ChatGPT read-before-write decisions.
create or replace function public.get_diet_context(
  p_end_date date default current_date,
  p_days integer default 14
) returns jsonb
language sql
security invoker
set search_path = public
as $$
  select jsonb_build_object(
    'generated_at', now(),
    'end_date', p_end_date,
    'days_requested', greatest(1, least(coalesce(p_days,14),90)),
    'profile', coalesce((select to_jsonb(p) - 'user_id' from public.profiles p where p.user_id = (select auth.uid())), '{}'::jsonb),
    'today', coalesce((select to_jsonb(ds) - 'user_id' from public.daily_summary ds where ds.user_id = (select auth.uid()) and ds.log_date = p_end_date), '{}'::jsonb),
    'recent_days', coalesce((select jsonb_agg(to_jsonb(ds) - 'user_id' order by ds.log_date) from public.daily_summary ds where ds.user_id = (select auth.uid()) and ds.log_date between p_end_date - (greatest(1,least(coalesce(p_days,14),90)) - 1) and p_end_date), '[]'::jsonb),
    'recent_weights', coalesce((select jsonb_agg(to_jsonb(w) - 'user_id' order by w.entry_date) from (select * from public.weight_entries where user_id=(select auth.uid()) and entry_date <= p_end_date order by entry_date desc limit 30) w), '[]'::jsonb),
    'today_meals', coalesce((select jsonb_agg(to_jsonb(md) - 'user_id' order by md.created_at) from public.meal_details md where md.user_id=(select auth.uid()) and md.log_date=p_end_date), '[]'::jsonb),
    'saved_foods', coalesce((select jsonb_agg(to_jsonb(sf) - 'user_id' order by sf.favorite desc, sf.use_count desc, sf.name) from (select * from public.saved_foods where user_id=(select auth.uid()) order by favorite desc,use_count desc,last_used_at desc nulls last limit 30) sf), '[]'::jsonb),
    'saved_meals', coalesce((select jsonb_agg(jsonb_build_object(
      'id', sm.id, 'name', sm.name, 'meal_type', sm.meal_type, 'favorite', sm.favorite, 'use_count', sm.use_count,
      'items', coalesce((select jsonb_agg(jsonb_build_object('id',smi.id,'name',smi.name,'quantity',smi.quantity_text,'calories',smi.calories,'protein',smi.protein,'calories_low',smi.calories_low,'calories_high',smi.calories_high,'confidence',smi.confidence,'source',smi.source) order by smi.sort_order) from public.saved_meal_items smi where smi.saved_meal_id=sm.id), '[]'::jsonb)
    ) order by sm.favorite desc, sm.use_count desc, sm.name) from (select * from public.saved_meals where user_id=(select auth.uid()) order by favorite desc,use_count desc,last_used_at desc nulls last limit 20) sm), '[]'::jsonb),
    'recent_ai_actions', coalesce((select jsonb_agg(to_jsonb(a) - 'user_id' order by a.created_at desc) from (select * from public.ai_actions where user_id=(select auth.uid()) order by created_at desc limit 10) a), '[]'::jsonb)
  );
$$;

create or replace function public.search_diet_history(
  p_query text,
  p_days integer default 120,
  p_limit integer default 20
) returns table(
  meal_id uuid,
  log_date date,
  meal_type text,
  title text,
  calories integer,
  protein numeric,
  confidence text,
  source text,
  updated_at timestamptz,
  items jsonb
)
language sql
security invoker
set search_path = public
as $$
  select md.id, md.log_date, md.meal_type, md.title, md.calories, md.protein, md.confidence, md.source,
         m.updated_at, md.items
  from public.meal_details md
  join public.meals m on m.id = md.id
  where md.user_id = (select auth.uid())
    and md.log_date >= current_date - greatest(1, least(coalesce(p_days,120),3650))
    and (
      md.title ilike '%' || coalesce(p_query,'') || '%'
      or coalesce(md.original_input,'') ilike '%' || coalesce(p_query,'') || '%'
      or coalesce(md.notes,'') ilike '%' || coalesce(p_query,'') || '%'
      or md.items::text ilike '%' || coalesce(p_query,'') || '%'
    )
  order by md.log_date desc, md.created_at desc
  limit greatest(1, least(coalesce(p_limit,20),100));
$$;

revoke all on function public.log_meal_from_ai(date,text,text,jsonb,text,text,text,text,text) from public, anon;
revoke all on function public.update_meal_from_ai(uuid,jsonb,jsonb,timestamptz,text) from public, anon;
revoke all on function public.delete_meal_from_ai(uuid,timestamptz,text) from public, anon;
revoke all on function public.log_weight_from_ai(date,numeric,text,text) from public, anon;
revoke all on function public.undo_ai_action(uuid) from public, anon;
revoke all on function public.get_diet_context(date,integer) from public, anon;
revoke all on function public.search_diet_history(text,integer,integer) from public, anon;

grant execute on function public.log_meal_from_ai(date,text,text,jsonb,text,text,text,text,text) to authenticated;
grant execute on function public.update_meal_from_ai(uuid,jsonb,jsonb,timestamptz,text) to authenticated;
grant execute on function public.delete_meal_from_ai(uuid,timestamptz,text) to authenticated;
grant execute on function public.log_weight_from_ai(date,numeric,text,text) to authenticated;
grant execute on function public.undo_ai_action(uuid) to authenticated;
grant execute on function public.get_diet_context(date,integer) to authenticated;
grant execute on function public.search_diet_history(text,integer,integer) to authenticated;

-- Keep AI actions visible to signed-in clients via Realtime as well.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') and not exists (
    select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='ai_actions'
  ) then
    alter publication supabase_realtime add table public.ai_actions;
  end if;
end $$;

-- V0.5 ownership-consistency hardening. RLS controls ownership of the child row;
-- these triggers additionally ensure relational parent IDs belong to the same user.
create or replace function public.diet_copilot_enforce_relation_owner()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  if tg_table_name = 'meals' then
    if not exists (select 1 from public.daily_logs d where d.id = new.daily_log_id and d.user_id = new.user_id) then
      raise exception 'daily_log_id must belong to the same user';
    end if;
  elsif tg_table_name = 'meal_items' then
    if not exists (select 1 from public.meals m where m.id = new.meal_id and m.user_id = new.user_id) then
      raise exception 'meal_id must belong to the same user';
    end if;
    if new.saved_food_id is not null and not exists (select 1 from public.saved_foods f where f.id = new.saved_food_id and f.user_id = new.user_id) then
      raise exception 'saved_food_id must belong to the same user';
    end if;
  elsif tg_table_name = 'saved_meal_items' then
    if not exists (select 1 from public.saved_meals sm where sm.id = new.saved_meal_id and sm.user_id = new.user_id) then
      raise exception 'saved_meal_id must belong to the same user';
    end if;
    if new.saved_food_id is not null and not exists (select 1 from public.saved_foods f where f.id = new.saved_food_id and f.user_id = new.user_id) then
      raise exception 'saved_food_id must belong to the same user';
    end if;
  end if;
  return new;
end;
$$;

revoke all on function public.diet_copilot_enforce_relation_owner() from public, anon;
grant execute on function public.diet_copilot_enforce_relation_owner() to authenticated;

do $$
begin
  drop trigger if exists diet_copilot_owner_guard on public.meals;
  create trigger diet_copilot_owner_guard before insert or update of user_id, daily_log_id on public.meals for each row execute function public.diet_copilot_enforce_relation_owner();
  drop trigger if exists diet_copilot_owner_guard on public.meal_items;
  create trigger diet_copilot_owner_guard before insert or update of user_id, meal_id, saved_food_id on public.meal_items for each row execute function public.diet_copilot_enforce_relation_owner();
  drop trigger if exists diet_copilot_owner_guard on public.saved_meal_items;
  create trigger diet_copilot_owner_guard before insert or update of user_id, saved_meal_id, saved_food_id on public.saved_meal_items for each row execute function public.diet_copilot_enforce_relation_owner();
end $$;

-- Release-candidate health endpoint used by Settings -> V0.5 release check.
create or replace function public.diet_copilot_healthcheck()
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_meal_parent_mismatch integer;
  v_item_parent_mismatch integer;
  v_saved_item_parent_mismatch integer;
  v_item_food_mismatch integer;
  v_saved_item_food_mismatch integer;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;

  select count(*) into v_meal_parent_mismatch
  from public.meals m
  where m.user_id = v_uid
    and not exists (select 1 from public.daily_logs d where d.id=m.daily_log_id and d.user_id=v_uid);

  select count(*) into v_item_parent_mismatch
  from public.meal_items i
  where i.user_id = v_uid
    and not exists (select 1 from public.meals m where m.id=i.meal_id and m.user_id=v_uid);

  select count(*) into v_saved_item_parent_mismatch
  from public.saved_meal_items i
  where i.user_id = v_uid
    and not exists (select 1 from public.saved_meals sm where sm.id=i.saved_meal_id and sm.user_id=v_uid);

  select count(*) into v_item_food_mismatch
  from public.meal_items i
  where i.user_id = v_uid and i.saved_food_id is not null
    and not exists (select 1 from public.saved_foods f where f.id=i.saved_food_id and f.user_id=v_uid);

  select count(*) into v_saved_item_food_mismatch
  from public.saved_meal_items i
  where i.user_id = v_uid and i.saved_food_id is not null
    and not exists (select 1 from public.saved_foods f where f.id=i.saved_food_id and f.user_id=v_uid);

  return jsonb_build_object(
    'schema_version', 5,
    'generated_at', now(),
    'counts', jsonb_build_object(
      'daily_logs', (select count(*) from public.daily_logs where user_id=v_uid),
      'meals', (select count(*) from public.meals where user_id=v_uid),
      'meal_items', (select count(*) from public.meal_items where user_id=v_uid),
      'saved_foods', (select count(*) from public.saved_foods where user_id=v_uid),
      'saved_meals', (select count(*) from public.saved_meals where user_id=v_uid),
      'weights', (select count(*) from public.weight_entries where user_id=v_uid),
      'ai_actions', (select count(*) from public.ai_actions where user_id=v_uid)
    ),
    'integrity', jsonb_build_object(
      'meal_parent_mismatch', v_meal_parent_mismatch,
      'meal_item_parent_mismatch', v_item_parent_mismatch,
      'saved_meal_item_parent_mismatch', v_saved_item_parent_mismatch,
      'meal_item_saved_food_mismatch', v_item_food_mismatch,
      'saved_meal_item_saved_food_mismatch', v_saved_item_food_mismatch
    ),
    'capabilities', jsonb_build_object(
      'get_diet_context', to_regprocedure('public.get_diet_context(date,integer)') is not null,
      'search_diet_history', to_regprocedure('public.search_diet_history(text,integer,integer)') is not null,
      'log_meal_from_ai', to_regprocedure('public.log_meal_from_ai(date,text,text,jsonb,text,text,text,text,text)') is not null,
      'update_meal_from_ai', to_regprocedure('public.update_meal_from_ai(uuid,jsonb,jsonb,timestamptz,text)') is not null,
      'delete_meal_from_ai', to_regprocedure('public.delete_meal_from_ai(uuid,timestamptz,text)') is not null,
      'log_weight_from_ai', to_regprocedure('public.log_weight_from_ai(date,numeric,text,text)') is not null,
      'undo_ai_action', to_regprocedure('public.undo_ai_action(uuid)') is not null
    )
  );
end;
$$;

revoke all on function public.diet_copilot_healthcheck() from public, anon;
grant execute on function public.diet_copilot_healthcheck() to authenticated;

